﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercicio_Proposto.Entities.Enums
{
	public enum StatusPedido : int
	{
		PagamentoPendente,
		Processando,
		Enviado,
		Entregue
	}
}
